package com.java.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.java.model.Student;
import com.java.repo.Studentrepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController

@RequestMapping("/students")
public class StudentController {

	 @Autowired
	    private Studentrepository Studentrepository;
	 
	 @PostMapping(path="/save")
	    public Student saveUser(@RequestBody Student stud){
		 System.out.println(stud);
	      
         Studentrepository.save(stud);

         return  stud;

	    }
	    
		
	    @GetMapping(path="/get")
	    public String gert() {
	    	return "kjnhbuhvjygcjygcjgc";
	    }
	    
	    
	    
	    public List<Student> listUser(){
	        return (List<Student>) Studentrepository.findAll();
	    }

	   /* @GetMapping("/{id}")
	    public ApiResponse<User> getOne(@PathVariable int id){
	        return new ApiResponse<>(HttpStatus.OK.value(), "User fetched successfully.",Studentrepository.findById(id));
	    }

	    @PutMapping("/{id}")
	    public ApiResponse<UserDto> update(@RequestBody UserDto userDto) {
	        return new ApiResponse<>(HttpStatus.OK.value(), "User updated successfully.",Studentrepository.update(userDto));
	    }

	    @DeleteMapping("/{id}")
	    public ApiResponse<Void> delete(@PathVariable int id) {
	    	Studentrepository.delete(id);
	        return new ApiResponse<>(HttpStatus.OK.value(), "User deleted successfully.", null);
	    }
	 */
	 
}
