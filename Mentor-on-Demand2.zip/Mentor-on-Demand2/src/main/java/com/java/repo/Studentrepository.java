package com.java.repo;

import org.springframework.data.repository.CrudRepository;

import com.java.model.Student;

public interface Studentrepository extends CrudRepository<Student,Long> {

}
