import { Component, OnInit } from '@angular/core';
import { DeviceService } from '../services/device.service';
import { map } from 'rxjs/operators';
@Component({
  selector: 'app-device-list',
  templateUrl: './device-list.component.html',
  styleUrls: ['./device-list.component.css']
})
export class DeviceListComponent implements OnInit {

  constructor(private deviceService : DeviceService) { }
  deviceArray = [];
  showSuccessMessage : boolean;
  showSuccessMessageDeleted: boolean;
  ngOnInit() {
   
    console.log(this.deviceService.getDevices1())
    this.deviceService.getDevices1().subscribe(
      list =>{
        this.deviceArray = list.map(item =>{
          return {
            $key:item.key,
            ...item.payload.val()


          };

        });
        
    }
    );
  
    
      }// end of Ngonit
 
     populateForm(device)
        {
          
          this.deviceService.populateForm(device)
         }

      toggle(device)
        {
          
          this.deviceService.toggleDone(device)
          this.showSuccessMessage = true
          setTimeout(()=>this.showSuccessMessage = false,3000);
         }

         deleteDevice(device)
         {
          console.log("Hey")
          this.deviceService.deleteDevice(device)
          this.showSuccessMessageDeleted = true
          setTimeout(()=>this.showSuccessMessageDeleted = false,3000);
         }
        }
//end of device list

      