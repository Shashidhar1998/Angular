export class Student{
    id:number;
    name:string;
    dept:string;
    
    public constructor(name:string,dept:string){
        this.name=name;
        this.dept=dept;
    }
}