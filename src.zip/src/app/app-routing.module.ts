import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainComponent } from './main/main.component';
import { HomeComponent } from './home/home.component';
import { ContentComponent } from './content/content.component';


const routes: Routes = [

{
  path:"main",component:MainComponent
},
{
  path:"home",component:HomeComponent,
  children:[{

    path:"content",component:ContentComponent
  },
      {
        path:"main1",component:MainComponent
      },
  {
    path:"",redirectTo:"content",pathMatch:"full"
  },
]
},
{
  path:"",redirectTo:"main",pathMatch:"full"
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
