import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Student } from 'src/models/Student';
import { StudentserviceService } from '../service/studentservice.service';
import { RouterLink, RouterOutlet, Router } from '@angular/router';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})

export class MainComponent implements OnInit {
  loginForm: FormGroup;
  studentdata;
  name;
  dept;
  constructor(private router:Router,private formBuilder: FormBuilder,private stservice:StudentserviceService) { }

  onSubmit() {
          console.log(this.name,this.dept);
      this.stservice.getString1().subscribe(res=>console.log(res),err=>console.log(this.stservice.baseUrl, status, err.toString()));
        var stud=new Student(this.name,this.dept);
        this.stservice.saveStudents(stud).subscribe(res=>{
          this.studentdata=res;
          console.log(this.studentdata);
          this.router.navigate(["/home"]);
        },err=>{
          console.log("err");
        });


    }

  

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
     name:[],
     department:[],
    });
   }

}
