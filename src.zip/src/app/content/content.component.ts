import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';
import { StudentserviceService } from '../service/studentservice.service';

@Component({
  selector: 'app-content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.css']
})
export class ContentComponent implements OnInit {

  constructor(private router:Router,private formBuilder: FormBuilder,private stservice:StudentserviceService) { }
Students;
Students1;
  ngOnInit() {
  }

  getStudents(){
    this.stservice.getStudents().subscribe(async res=>{
      this.Students=await res;
    },err=>{
      console.log("err");
    }
    )
    console.log(this.Students)
  }

  getStudents1(){
    this.stservice.getStudents().subscribe(async res=>{
      this.Students=await res;
    },err=>{
      console.log("err");
    }
    )
    console.log(this.Students)
  }
}
