import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Student } from 'src/models/Student';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StudentserviceService {

  constructor(private http:HttpClient) { }
  baseUrl="http://localhost:8080/students/";



  saveStudents(stud:Student):Observable<any>{
    return this.http.post(`${this.baseUrl}save`,stud);
  }

  getString1():Observable<any>
  {
    return this.http.get<String>(`${this.baseUrl}get`);
  }
}
