import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { IndexComponent } from './index/index.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { ProfileComponent } from './profile/profile.component';
import { LoginComponent } from './login/login.component';
const routes: Routes = [
  {
    path:'',redirectTo:'home',pathMatch:'full'
  },
  {
    path:'home',component:IndexComponent,
  },
  {
    path:'login',component:LoginComponent,
  },
  {
    path:'dashboard',component:DashboardComponent,
    children:[
      {
        path:'',redirectTo:'profile',pathMatch:'full'
      },
      {
        path:'profile',component:ProfileComponent
      }
    ]
  },
  { 
    path: '**', component: PagenotfoundComponent 
  },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }


/*
 {
    path:'home',component:IndexComponent,
    children:[
      {
        path:'',redirectTo:'dashboard',pathMatch:'full'
      },
      {
        path:'dashboard',component:DashboardComponent
      },
      {
        path:'profile',component:ProfileComponent
      }
    ]
  },
*/