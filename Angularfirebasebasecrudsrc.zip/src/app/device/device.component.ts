import { Component, OnInit } from '@angular/core';
import { DeviceService } from '../services/device.service';
@Component({
  selector: 'app-device',
  templateUrl: './device.component.html',
  styleUrls: ['./device.component.css']
})
export class DeviceComponent implements OnInit {

 
  constructor(private deviceService : DeviceService) { }
  submitted : boolean;
  showSuccessMessage : boolean;
  formControls  = this.deviceService.form.controls


  ngOnInit() {
  }
  
  onSubmit(){
    this.submitted = true
    //console.log(this.deviceService.form.value)
    //console.log(this.deviceService.form.valid)
    //console.log(this.deviceService.form.get('$key').value==null)
    if(this.deviceService.form.valid)
    {// Insert the form
      if(this.deviceService.form.get('$key').value==null)
      {
        console.log(this.deviceService.form.value)
        this.deviceService.adddevice(this.deviceService.form.value);
        this.showSuccessMessage = true
        setTimeout(()=>this.showSuccessMessage = false,3000);
      }
      this.submitted = false
      this.deviceService.form.reset();
    }
    else
    {
      //Update the form

    }
  }
}
